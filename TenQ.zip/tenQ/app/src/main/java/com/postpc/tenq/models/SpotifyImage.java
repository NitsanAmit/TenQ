package com.postpc.tenq.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class SpotifyImage implements Serializable {

    @SerializedName("url")
    String url;

}
