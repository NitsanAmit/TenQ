package com.postpc.tenq.ui.listeners;

import com.postpc.tenq.models.Track;

public interface ITrackActionListener {

    void onTrackLikeToggle(Track track);

}
